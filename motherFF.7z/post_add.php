
<?php

$pdo = new PDO('mysql:host=localhost; dbname=post_it', 'root');
$sql = "INSERT INTO"