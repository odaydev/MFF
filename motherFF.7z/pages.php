<?php include 'includes/header.php'; ?>

		<form id="search-field">
			<input type="search" name="search" id="search-input" value="Search"/>			
		</form>
		<div class="page-content clearfix">
			<div class="topics page-content-centered">
				<h2>Selectionner un topic</h2>
				<article class="topics-box clearfix">
					<a href="">
						<div class="always-visible">
							<h2>Whats is MotherFucking Forum</h2>
							<h3>User's name</h3>
							<img src="img/identity-grey-icon.png" alt="nom de la personne" height="16" width="16"/>
							<h4>02 Decembre 2015</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
							</p>
						</div>
					</a>
				</article>			
				<article class="topics-box clearfix">
					<a href="">
						<div class="always-visible">
							<h2>Whats is MotherFucking Forum</h2>
							<h3>User's name</h3>
							<img src="img/identity-grey-icon.png" alt="nom de la personne" height="16" width="16"/>
							<h4>02 Decembre 2015</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
							</p>
						</div>
					</a>
				</article>			
				<article class="topics-box clearfix">
					<a href="">
						<div class="always-visible">
							<h2>Whats is MotherFucking Forum</h2>
							<h3>User's name</h3>
							<img src="img/identity-grey-icon.png" alt="nom de la personne" height="16" width="16"/>
							<h4>02 Decembre 2015</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
							</p>
						</div>
					</a>
				</article>			
				<article class="topics-box clearfix">
					<a href="">
						<div class="always-visible">
							<h2>Whats is MotherFucking Forum</h2>
							<h3>User's name</h3>
							<img src="img/identity-grey-icon.png" alt="nom de la personne" height="16" width="16"/>
							<h4>02 Decembre 2015</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
							</p>
						</div>
					</a>
				</article>
				<article class="topics-box clearfix">
					<a href="">
						<div class="always-visible">
							<h2>Whats is MotherFucking Forum</h2>
							<h3>User's name</h3>
							<img src="img/identity-grey-icon.png" alt="nom de la personne" height="16" width="16"/>
							<h4>02 Decembre 2015</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
							</p>
						</div>
					</a>
				</article>
				<article class="topics-box clearfix">
					<a href="">
						<div class="always-visible">
							<h2>Whats is MotherFucking Forum</h2>
							<h3>User's name</h3>
							<img src="img/identity-grey-icon.png" alt="nom de la personne" height="16" width="16"/>
							<h4>02 Decembre 2015</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
							</p>
						</div>
					</a>
				</article>
				<article class="topics-box clearfix">
					<a href="">
						<div class="always-visible">
							<h2>Whats is MotherFucking Forum</h2>
							<h3>User's name</h3>
							<img src="img/identity-grey-icon.png" alt="nom de la personne" height="16" width="16"/>
							<h4>02 Decembre 2015</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
							</p>
						</div>
					</a>
				</article>
				<article class="topics-box clearfix">
					<a href="">
						<div class="always-visible">
							<h2>Whats is MotherFucking Forum</h2>
							<h3>User's name</h3>
							<img src="img/identity-grey-icon.png" alt="nom de la personne" height="16" width="16"/>
							<h4>02 Decembre 2015</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
							</p>
						</div>
					</a>
				</article>
			
			</div>
		</div>
		<?php include 'includes/footer.php'; ?>