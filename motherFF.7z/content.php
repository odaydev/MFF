<?php  include 'includes/header.php';  ?>

		<form id="search-field">
			<input type="search" name="search" id="search-input" value="Search"/>			
		</form>
		
		<section class="content clearfix">
			<div class="content-centered">
				<div class="topic clearfix">
					<figure><img src="img/3.png" height="480" width="480"></figure>
					<article class="clearfix">
						<h2>What is Post it?</h2>

						<div class="user-comments">
							<img src="img/user1.png" alt="nom de la personne" height="64" width="64"/>
							<h2>Elsa</h2>
							<h4>02 Decembre 2015</h4>
						</div>

						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
					</article>
				</div>
				<!--Commentaires des autres utilisateurs-->
				<aside class=" comments-submit clearfix">
					<h2>Commentaires</h2>
					<form>
					<textarea placeholder="Ajouter un commentaire"></textarea>
					<input type="submit" name="comment" value="Envoyer" />						
					</form>
				</aside>
				<div class="comments clearfix">
					<article class="comments-box clearfix">
						<div class="user-comments">
							<img src="img/user1.png" alt="nom de la personne" height="64" width="64"/>
							<h2>User's name</h2>
							<h4>02 Decembre 2015</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
					</article>
					<article class="comments-box clearfix">
						<div class="user-comments">
							<img src="img/user1.png" alt="nom de la personne" height="64" width="64"/>
							<h2>User's name</h2>
							<h4>02 Decembre 2015</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
					</article>
					<article class="comments-box clearfix">
						<div class="user-comments">
							<img src="img/user1.png" alt="nom de la personne" height="64" width="64"/>
							<h2>User's name</h2>
							<h4>02 Decembre 2015</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
					</article>
				</div>
			</div>
		</section>


	<?php  include 'includes/footer.php';  ?>
