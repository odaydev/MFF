<?php include 'includes/header.php'; ?>

		<section id="main-part" class="clearfix">
			<figure class="img-content">
					<img src="img/1.png" alt="" width="100%" height="100%" />
				<figcaption class="hover-description">
					<div class="centered">
						<div class="always-visible clearfix">
							<h2>Ezequeil Gonzalez book.</h2>
							<img src="img/identity-icon.png" alt="nom de la personne" height="16" width="14"/>
							<p>Johnny</p>
							<img src="img/heart-icon.png" alt="j'aime" height="16" width="14"/>
							<p>15</p>
							<img src="img/message-icon.png" alt="commentaire" height="16" width="14"/>
							<p>22</p>
						</div>
						<!--Contenu caché, apparait au survol-->
						<div class="hidden-content clearfix">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
						</div>
						<a class="more-btn" href="content.php">Read More</a>
					</div>
				</figcaption>
			</figure>
			
			<figure class="img-content" class="clearfix">
					<img src="img/2.png" alt="" width="100%" height="100%" />
				<figcaption class="hover-description">
					<div class="centered">
						<div class="always-visible clearfix">
							<h2>Ezequeil Gonzalez book.</h2>
							<img src="img/identity-icon.png" alt="nom de la personne" height="16" width="14"/><p>Johnny</p>
							<img src="img/heart-icon.png" alt="j'aime" height="16" width="14"/><p>15</p>
							<img src="img/message-icon.png" alt="commentaire" height="16" width="14"/><p>22</p>
						</div>
						<div class="hidden-content clearfix">
							<p class="text-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
						</div>
						<a class="more-btn" href="">Read More</a>
					</div>
				</figcaption>
			</figure>
			<figure class="img-content" class="clearfix">
					<img src="img/3.png" alt="" width="100%"/>
				<figcaption class="hover-description">
					<div class="centered">
						<div class="always-visible clearfix">
							<h2>Ezequeil Gonzalez book.</h2>
							<img src="img/identity-icon.png" alt="nom de la personne" height="16" width="14"/><p>Johnny</p>
							<img src="img/heart-icon.png" alt="j'aime" height="16" width="14"/><p>15</p>
							<img src="img/message-icon.png" alt="commentaire" height="16" width="14"/><p>22</p>
						</div>
						<div class="hidden-content clearfix">
							<p class="text-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
						</div>
						<a class="more-btn" href="">Read More</a>
					</div>
				</figcaption>
			</figure>
			<figure class="img-content" class="clearfix">
					<img src="img/4.png" alt="" width="100%"/>
				<figcaption class="hover-description">
					<div class="centered">
						<div class="always-visible clearfix">
							<h2>Ezequeil Gonzalez book.</h2>
							<img src="img/identity-icon.png" alt="nom de la personne" height="16" width="14"/><p>Johnny</p>
							<img src="img/heart-icon.png" alt="j'aime" height="16" width="14"/><p>15</p>
							<img src="img/message-icon.png" alt="commentaire" height="16" width="14"/><p>22</p>
						</div>
						<div class="hidden-content clearfix">
							<p class="text-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
						</div>
						<a class="more-btn" href="">Read More</a>
					</div>
				</figcaption>
			</figure>
			<figure class="img-content" class="clearfix">
					<img src="img/5.png" alt="" width="100%"/>
				<figcaption class="hover-description">
					<div class="centered">
						<div class="always-visible clearfix">
							<h2>Ezequeil Gonzalez book.</h2>
							<img src="img/identity-icon.png" alt="nom de la personne" height="16" width="14"/><p>Johnny</p>
							<img src="img/heart-icon.png" alt="j'aime" height="16" width="14"/><p>15</p>
							<img src="img/message-icon.png" alt="commentaire" height="16" width="14"/><p>22</p>
						</div>
						<div class="hidden-content clearfix">
							<p class="text-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
						</div>
						<a class="more-btn" href="">Read More</a>
					</div>
				</figcaption>
			</figure>
			<figure class="img-content" class="clearfix">
					<img src="img/6.png" alt="" width="100%"/>
				<figcaption class="hover-description">
					<div class="centered">
						<div class="always-visible clearfix">
							<h2>Ezequeil Gonzalez book.</h2>
							<img src="img/identity-icon.png" alt="nom de la personne" height="16" width="14"/><p>Johnny</p>
							<img src="img/heart-icon.png" alt="j'aime" height="16" width="14"/><p>15</p>
							<img src="img/message-icon.png" alt="commentaire" height="16" width="14"/><p>22</p>
						</div>
						<div class="hidden-content clearfix">
							<p class="text-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
						</div>
						<a class="more-btn" href="">Read More</a>
					</div>
				</figcaption>
			</figure>
			<figure class="img-content" class="clearfix">
					<img src="img/7.png" alt="" width="100%"/>
				<figcaption class="hover-description">
					<div class="centered">
						<div class="always-visible clearfix">
							<h2>Ezequeil Gonzalez book.</h2>
							<img src="img/identity-icon.png" alt="nom de la personne" height="16" width="14"/><p>Johnny</p>
							<img src="img/heart-icon.png" alt="j'aime" height="16" width="14"/><p>15</p>
							<img src="img/message-icon.png" alt="commentaire" height="16" width="14"/><p>22</p>
						</div>
						<div class="hidden-content clearfix">
							<p class="text-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
						</div>
						<a class="more-btn" href="">Read More</a>
					</div>
				</figcaption>
			</figure>
			<figure class="img-content" class="clearfix">
					<img src="img/8.png" alt="" width="100%"/>
				<figcaption class="hover-description">
					<div class="centered">
						<div class="always-visible clearfix">
							<h2>Ezequeil Gonzalez book.</h2>
							<img src="img/identity-icon.png" alt="nom de la personne" height="16" width="14"/><p>Johnny</p>
							<img src="img/heart-icon.png" alt="j'aime" height="16" width="14"/><p>15</p>
							<img src="img/message-icon.png" alt="commentaire" height="16" width="14"/><p>22</p>
						</div>
						<div class="hidden-content clearfix">
							<p class="text-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
						</div>
						<a class="more-btn" href="">Read More</a>
					</div>
				</figcaption>
			</figure>
		</section>
		
<?php include 'includes/footer.php';  ?>